export const data = [
    {
        id: 'asd',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asad',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asdss',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asdasd',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asdqweqwe',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asdzxczxc',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asdzxccv',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asdlsld',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asdqasde',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
    {
        id: 'asdolikdhjf',
        fullName: 'Jhon',
        role: 'Maneger',
        email: 'Jhon@gmai.com',
        phone: '+352128541252'
    },
];